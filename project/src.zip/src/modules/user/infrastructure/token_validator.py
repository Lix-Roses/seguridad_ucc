from fastapi import Header, HTTPException, Depends
from sqlalchemy.orm import Session
from datetime import datetime, timezone
from src.shared.config.database import get_db
from src.modules.user.infrastructure.token_repository import TokenRepository


def verify_token(authorization: str = Header(...), db: Session = Depends(get_db)):
    if not authorization.startswith("Bearer "):
        raise HTTPException(status_code=401, detail="Formato inválido. Usa: Bearer <token>")

    token_str = authorization.replace("Bearer ", "")
    token = TokenRepository.get_by_token(db, token_str)

    if not token:
        raise HTTPException(status_code=401, detail="Token no existe")

    if token.expires_at < datetime.now(timezone.utc):
        raise HTTPException(status_code=401, detail="Token expirado")

    return token